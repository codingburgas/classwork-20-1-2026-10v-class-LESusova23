#include <iostream>
//#include "../MathLibrary/MathLibrary.h"
using namespace std;

int main() {
	int a, b, c;
	cin >> a >> b >> c;
	cout << calcPAndS(a, b, c);
}