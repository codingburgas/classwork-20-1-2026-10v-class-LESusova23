
#include <iostream>
#include"../MathLibrary/MathLibrary.h"
using namespace std;
int main()
{
    calcPAndS(3, 4, 5);
}