#include "pch.h"
#include "framework.h"
#include <iostream>
#include "MathLibrary.h"
using namespace std;

void calcPAndS(int a, int b, int c)
{
	int P = a + b + c;
	float S = (a * b) / 2;
	cout << P << " " << S;

}
