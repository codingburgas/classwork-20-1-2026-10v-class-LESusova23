#pragma once
#include <iostream>
#include "../Project1/addition.h"
using namespace std;
void calcPAndS(int a, int b, int c);